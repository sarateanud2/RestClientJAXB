package com.client.main;

import javax.ws.rs.core.MediaType;

import com.client.objects.Eployee;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class Main {


	public static void main(String[] args) {
		
		try {
			Eployee employee;
			Client client = Client.create();
			
			WebResource webResource = client.resource("http://localhost:8080/RestFull01/run/");
			
			ClientResponse response = webResource.path("getemployee").accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);
			
			if (response.getStatus() != 200) {
				   throw new RuntimeException("Failed : HTTP error code : "
					+ response.getStatus());
			}
			
			employee = response.getEntity(Eployee.class);
			
			System.out.println("Output from Server .... \n");
			System.out.println(employee);
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}
