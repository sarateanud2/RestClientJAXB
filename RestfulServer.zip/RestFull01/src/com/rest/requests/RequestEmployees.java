package com.rest.requests;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.rest.employees.Eployee;

@Path("getemployee")
@Produces(MediaType.APPLICATION_JSON)
public class RequestEmployees {
	
	@GET
	public Eployee getEmployeeInJSON(){
		Eployee em1 = new Eployee("Dumitru", "Sarateanu", 50000);
		
		return em1;
	}
	

}
