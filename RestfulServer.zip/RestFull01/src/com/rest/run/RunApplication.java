package com.rest.run;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("run")
public class RunApplication extends Application{

}
