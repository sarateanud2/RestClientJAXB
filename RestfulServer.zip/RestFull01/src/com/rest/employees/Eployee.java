package com.rest.employees;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Eployee {
	
	@XmlElement(name = "fname")
	private String fName; 
	
	@XmlElement(name = "lname")
	private String lName; 
	
	@XmlElement(name = "salary")
	private int salary;

	public Eployee() {
		super();
	}

	public Eployee(String fName, String lName, int salary) {
		super();
		this.fName = fName;
		this.lName = lName;
		this.salary = salary;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

}
